@extends('layouts.app')

@section('content')



<div class="w-100 img-fundo-1" id="inicio">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10" style="margin-top: 10%;height:650px;">
                <img src="./img/icones/not1.png" alt="" style="width: 70%;margin-bottom: 10%;">
                <h1 class="text-white" style="font-size:60px;font-weight:800;"><b>FAÇA <br> PARTE <br> DO <span style="color:#FF8F1C;font-size:75px;">ST</span> </b></h1>
                <p class="text-white py-3" style="width: 350px">Organização fundada em 2019, com uma ideia de juntar amigos, conseguimos mais do que isso e hoje, <b>somos um time E-sports.</b>
                </p>

                <button class="btn px-4 btn-principal text-white" type="button" style="border-radius:10px;">FAÇA PARTE DO TIME</button>
                <button class="btn px-4" type="button" style="color:#fff;border-radius:10px;border:1 solid #fff;border-color:#fff;">TORNEIOS</button>
            </div>
        </div>

    </div>
</div>

<div class="w-100" style="background: #FF8F1C;">
    <div class="container">
        <div class="row justify-content-center pt-5">
            <div class="col-12 col-md-2">
                <h2 class="font-weight-bold">SOBRE <br> A <span class="text-white">ST</span></h2>
            </div>
            <div class="col-12 col-md-2 pt-4">
                <div class="border border-dark w-100 my-3"></div>
            </div>
            <div class="col-12 col-md-6 pb-4">
                <h4 class="">Organização fundada em 2019, com uma ideia de juntar amigos, conseguimos ser mais do que isso e hoje, somos um time de E-sports...  <a href="#" class="text-white">Ver mais</a> </h4>
            </div>
        </div>
    </div>
</div>

<div class="w-100">
    <div class="container">

        <div class="w-100 mx-auto text-center py-5">
            <img src="{{ env('APP_URL') }}/assets/img/banners/bannerpix.png" alt="" class="bannerpix" style="margin-bottom: 10%;">
        </div>

 

       <div class="row justify-content-center">
           <div class="col-3">
                <div class="border w-100 my-3"></div>
           </div>
           <div class="col-12 col-md-2 text-center">
            <h3><b>TORNEIOS</b></h3>
           </div>
           <div class="col-3">
                <div class="border w-100 my-3"></div>
           </div>
       </div>

        <div class="row justify-content-center pt-5">

            @foreach ($torneios as $torneio )
                <div class="col-12 col-md-3 my-2">
                    <div class="card text-white" style="border-radius: 10px 10px;background-color:#16253A;">
                        <div style="border-radius: 10px 10px;width: 100%;height:160px; border:3px solid #FF8F1C;">
                            <img src="{{ env('APP_URL') }}/storage/img/torneios/{{ $torneio->imagem }}" style="width:100%;height:100%;object-fit: cover;border-radius: 7px 7px;">
                        </div>
                        <div class="card-body">
                        <h5 class="card-title">{{ $torneio->titulo }}</h5>
                        <p class="card-text small" style="height: 100px">
                            {{-- {{ $torneio->premiacao }} --}}
                            1° Lugar: R$ 800 <br>
                            2° Lugar: R$ 800 <br>
                            3° Lugar: R$ 800 <br>
                            4° Lugar: R$ 800 <br>
                            5° Lugar: R$ 800
                        </p>
                        <p class="small">
                            <span class="px-2" style="border:1px solid #FF8F1C; border-radius:8px;">PLAYERS {{ $torneio->qtd_players }}</span>
                            <span class="px-2" style="border:1px solid #FF8F1C; border-radius:8px;">VALOR {{ number_format($torneio->valor_inscricao, 2, ',', '.') }}</span>
                        </p>
                        
                        <p>{{ $torneio->data_evento }}, {{ $torneio->duracao_media }} - BR</p>

                        </div>
                    </div>
                </div>
            @endforeach

        </div>

        <div class="w-100 text-center py-5">
            <a href="#" class="text-dark"><h4><b>VER TODOS OS TORNEIOS</b></h4></a>
        </div>
    </div>
</div>

<div class="w-100" style="background: #181818;">
    <div class="container">
        <div class="row justify-content-center pt-5">
            <div class="col-3">
                <div class="border w-100 my-3"></div>
            </div>
            <div class="col-12 col-md-3 text-center">
                <h4 class="text-white">ADMINISTRADORES</h4>
            </div>
            <div class="col-3 pb-4">
                <div class="border w-100 my-3"></div>
            </div>
        </div>

        <div class="row justify-content-center pb-5">

            @php
                $i = 1
            @endphp

            @foreach ($users as $user)

                @if (!empty($user->user_players[0]))

                    <div class="col-12 col-md-3 my-3">
                        <div style="border-radius: 10px 10px;background-color:#fff;">
                            <div class="text-center" style="border-radius: 10px 10px;width: 100%;height:190px;">
                                <img src="{{ env('APP_URL') }}/assets/img/avatars/persona-{{$i}}.png" class="mt-1" style="width:60%;height:100%;object-fit: cover;">
                            </div>
                            <div class="text-center text-white" style="border-radius: 10px 10px;width: 100%;height:110px; border:3px solid #444444; background-color:#444444;">
                                <h5 class="card-title mt-3">{{ $user->user_players[0]->nome }}</h5>
                                <span>{{ $user->user_players[0]->descricao }}</span>
                            </div>
                        </div>
                    </div>

                    @if ($i == 4)
                        {{ $i = 1 }}
                    @endif
                    
                @endif

                
                
            @endforeach
            

        </div>
    </div>


    <div class="img-fundo-2 text-center" style="height:450px; border-radius:0px 0px 150px 150px;">

            <h1 class="text-white" style="padding-top:10%"><b>NÃO SOMOS SÓ UM TIME, SOMOS UMA FAMÍLIA</b></h1>
            <div class="w-25 mx-auto mt-5 border"></div>

    </div>
    
    <div class="container">
        <div class="row justify-content-center pt-3">

            <div class="col-4">
                <div class="border w-100 my-3"></div>
            </div>
            <div class="col-12 col-md-4 text-center">
                <a data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample" style="text-decoration:none">
                    <h4 class="text-principal"><b>JOGOS PRINCIPAIS</b></h4>
                </a>
            </div>
            <div class="col-4 pb-4">
                <div class="border w-100 my-3"></div>
            </div>
            
        </div>

        <div class="collapse" id="collapseExample">
            
            <div class="row justify-content-center text-white">
                
                @foreach ($games as $game)

                @if ($game->ativo == 1)
                    <div class="col-md-3 text-center">
                        <div>
                            <p >
                                <div class="mx-auto" style="width: 50%;height:80px;">
                                    <img src="{{ env('APP_URL') }}/storage/img/games/{{ $game->imagem }}" style="width:70%;height:100%;object-fit: contain;border-radius: 30%;">
                                </div>
                            </p>
                            <h4>{{ $game->nome }}</h4>
                            <p>{{ $game->descricao }}</p>
                        </div>
                    </div>
                    
                @endif

                
                @endforeach

                <div class="w-100 text-center my-4">
                    <button class="btn px-4 btn-principal text-white" type="button" style="border-radius:10px;">FAÇA PARTE DO TIME</button>
                <button class="btn px-4" type="button" style="color:#fff;border-radius:10px;border:1 solid #fff;border-color:#fff;">VER TODOS OS TIMES</button>
                </div>

            </div>
            

            

        </div>

    </div>
</div>

<div class="w-100" style="background: #F1F1F1">
    <div class="container">

       <div class="row justify-content-center pt-5">
           <div class="col-4">
               <hr>
           </div>
           <div class="col-12 col-md-4 text-center">
            <h4><b>LÍDERES DE SQUAD</b></h4>
           </div>
           <div class="col-4">
               <hr>
           </div>
       </div>

            @foreach ($games as $game)
            <div class="row justify-content-center pt-5">
                
                <div class="w-100">
                    <h4 class="text-center mb-4">{{$game->nome}}</h4>
                </div>
                @foreach ($game->games_time as $time )
               
                        {{-- Verifica se possui lider no time do respectivo jogo --}}
                        @if (!empty($time->time_playes))
                            @if ($time->time_playes->status == 1)
                                {{-- <h5 class="text-center mb-4">{{$time->nome}}</h5> --}}
                                {{-- {{ $time->time_playes->player_time}} --}}

                                {{-- <div class="col-12 col-md-3 my-3">
                                    <div style="border-radius: 10px 10px;background-color:#fff;">
                                        <div class="text-center" style="border-radius: 10px 10px;width: 100%;height:150px;">
                                            <img src="{{ env('APP_URL') }}/assets/img/avatars/persona-1.png" class="mt-1" style="width:60%;height:100%;object-fit: cover;">
                                        </div>
                                        <div class="text-center text-white" style="border-radius: 10px 10px;width: 100%;height:80px; border:3px solid #444444; background-color:#444444;">
                                            <h5 class="card-title mt-3">{{ $time->time_playes->player_time->nome }}</h5>
                                            
                                        </div>
                                    </div>
                                </div> --}}

                            @endif
                        
                        @else

                            {{-- <p>Game não possui Lider</p> --}}

                        @endif
                        
                @endforeach

            </div>
            @endforeach

        <div class="w-100 text-center py-5">
            <button class="btn px-4 btn-primeira text-white" type="button" style="border-radius:10px;">FAÇA PARTE DO TIME</button>
        </div>
    </div>
</div>

@if (count($playersPatrocinados) != 0)

<div class="w-100 pt-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-3">
                 <div class="border w-100 my-3"></div>
            </div>
            <div class="col-12 col-md-5 text-center">
             <h4><b>STREAMER PATROCINADO</b></h4>
            </div>
            <div class="col-3">
                 <div class="border w-100 my-3"></div>
            </div>
        </div>

        
            <div class="row justify-content-center">
                
                @foreach ($playersPatrocinados as $streamer)
                    <div class="col-7 col-md-2 my-3">
                        <div class="w-100 text-center">
                            <div class="mx-auto" style="border-radius: 30px 30px;width: 100px;height:100px;box-shadow: 3px 3px 0.3em #000;">
                                <img src="{{ $streamer->player_users->avatar }}" style="width:100%;height:100%;object-fit: contain;border-radius: 20px 20px;">
                            </div>
                            <p class="mt-3"><b>{{ $streamer->nome }}</b></p>
                        </div>
                    </div>
                @endforeach
            </div>
    </div>
</div>
@endif







@endsection