@extends('layouts.adm')

@section('content')
<div class="container">
    <div class="row justify-content-center text-center">

        <div class="col">
            <h3>escudos</h3>
        </div>
            
    </div>
</div>
@endsection