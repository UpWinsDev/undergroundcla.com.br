

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center mb-5">


    <div class="col-md-8">

      

    <div class="w-100 text-center my-5">
        <h3 class="text-white"><b>EDITAR TORNEIO</b></h3>
    </div>

    <div class="col-md-12">
        <?php if(Session::has('mensagem-falha')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Ops!</strong> <?php echo e(Session::get('mensagem-falha')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
        <?php endif; ?>
        <?php if(Session::has('mensagem-sucesso')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Show!</strong> <?php echo e(Session::get('mensagem-sucesso')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
        <?php endif; ?>
    </div>

        <div class="w-100 bg-white p-3 mb-5" style="border-radius:10px;">
          <form action="<?php echo e(route('torneios.edit.do', ['id'=> $torneio->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="titulo">Titulo</label>
                <input type="text" class="form-control" id="titulo" name="titulo" value="<?php echo e($torneio->titulo); ?>" value="<?php echo e($torneio->titulo); ?>" required>
              </div>
              <div class="form-group col-md-3">
                <label for="qtd_players">Qntd de playes</label>
                <input type="text" class="form-control" id="qtd_players" name="qtd_players" value="<?php echo e($torneio->qtd_players); ?>" required>
              </div>
              
              <div class="form-group col-md-3">
                <label for="premiacao">Qntd premiações</label>
                <input type="text" class="form-control" id="premiacao" name="premiacao" value="<?php echo e($torneio->premicacao); ?>" required>
              </div>
              <div class="form-group col-md-3">
                <label for="id_game">Game</label>
                <select class="form-control" id="id_game" name="id_game">
                    <option value="<?php echo e($torneio->torneio_game->id); ?>"><?php echo e($torneio->torneio_game->nome); ?></option>

                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($game->id != $torneio->id_game): ?>
                            <option value="<?php echo e($game->id); ?>"><?php echo e($game->nome); ?></option>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <option value="">Selecione categoria</option>

                </select>
              </div>
              <div class="form-group col-md-3">
                <label for="duracao_media">Duração média</label>
                <input type="time" class="form-control" id="duracao_media" name="duracao_media" value="<?php echo e($torneio->duracao_media); ?>" required>
              </div>
              <div class="form-group col-md-3">
                <label for="valor_inscricao">Valor inscrição</label>
                <input type="text" class="form-control" id="valor_inscricao" name="valor_inscricao" value="<?php echo e($torneio->valor_inscricao); ?>" required>
              </div>
              <div class="form-group col-md-3">
                <label for="data_evento">Data Evento</label>
                <input type="date" class="form-control" id="data_evento" name="data_evento" value="<?php echo e($torneio->data_evento); ?>" required>
              </div>
              <div class="form-group col-md-12">
                <label for="descricao">Regras e descrição</label>
                <textarea class="form-control" d="descricao" name="descricao" rows="3"><?php echo e($torneio->descricao); ?></textarea>
              </div>
              
              <div class="form-group col-md-4 text-center">
                <div  style="border-radius: 10px 10px 0px 0px;width: 100%;height:160px;">
                  <img src="<?php echo e(env('APP_URL')); ?>/storage/img/torneios/<?php echo e($torneio->imagem); ?>" class="mt-2" style="width:140px;height:140px;object-fit: cover;">
                </div>
              </div>

              <div class="form-group col-md-7">
                  <div class="custom-file">
                      <input type="file" class="custom-file-input" id="customFile" name="arquivo">
                      <label class="custom-file-label" for="customFile">Alterar imagem</label>
                  </div>
              </div>
            </div>
            <a class="btn btn-primary" role="button" href="<?php echo e(route('adm.torneios.index')); ?>">Voltar</a>
            <button class="btn btn-success" type="submit">Salvar</button>
          </form>
        </div>

    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp_server\htdocs\dev-upwins\undergroundcla.com.br\resources\views/admin/torneios/edit.blade.php ENDPATH**/ ?>