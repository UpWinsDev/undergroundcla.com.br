<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/app.css')); ?>" rel="stylesheet">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    
</head>
<body>
    <div id="app">
        
        
          <header class="sticky-top">
            <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">

                    <a class="navbar-brand d-block d-lg-none" href="#">
                        <img src="<?php echo e(asset('assets/img/logo-principal.png')); ?>" alt="" class="img-logo"  style="width: 50px; ">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mx-auto mb-2 mt-3 mb-lg-0">
                            <li class="nav-item active">
                                <a class="nav-link" href="<?php echo e(route('home.index')); ?>">INÍCIO</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('home.sobre')); ?>">SOBRE</a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('home.recrutamento')); ?>">RECRUTAMENTO</a>
                            </li>
                            <li class="nav-item d-none d-lg-block nav-img-logo" style="width: 140px; margin-top:-25px;">
                                <a class="navbar-brand btn-block" href="#" >
                                    <img src="<?php echo e(asset('assets/img/logo-principal.png')); ?>" alt="" class="img-logo"  style="width: 130px; border-radius:100%;position: absolute;">
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('home.torneios')); ?>">TORNEIOS</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('home.torneios')); ?>">CONTATO</a>
                            </li>
                            
                            <li class="nav-item dropdown d-flex">
    
                                <?php if(Auth::check() ): ?>
                                
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" role="button" data-toggle="dropdown" aria-expanded="false">

                                        <img src="<?php echo e(Auth::user()->avatar); ?>" alt="" style="width: 30px;border-radius:50px;">
                                        
                                        Olá, <?php echo e(Auth::user()->username); ?>

                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                        <li><a class="dropdown-item" href="<?php echo e(route('home.contribuir')); ?>">Contribuir</a></li>
                                        <?php if(Auth::user()->nivel == 1): ?>
                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">Area restrita</a></li>
                                        <?php endif; ?>
                                        <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Sair</a></li>
                                        
                                    </ul>
    
                                    
            
                                <?php else: ?>
                                    <a href="<?php echo e(route('auth.steam')); ?>" class="nav-link"><img src="<?php echo e(asset('assets/img/login.png')); ?>" alt="" class="pr-2" style="width: 25px"> Fazer login</a>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
               
            </nav>
        </header>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <footer>
            <div class="w-100 img-fundo-doacao">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-12" style="margin-top: 5%;height:400px;">
             
                            <div class="mx-auto" style="width: 300px">
                                <img src="<?php echo e(asset('assets/img/game-06.png')); ?>" alt="" class="float-left" style="width: 70px">
                                <h4 class="text-white text-center font-weight-bold">FAÇA PARTE DA NOSSA DOAÇÃO:</h4>
                            </div>
                            <p class="text-white text-center mx-auto py-4" style="max-width: 500px">Conectamos gamers que tem equipamentos para doar, com outros gamers que necessitam de um equipamento. Colabore com o ST!
                            </p>
            
                            <div class="mx-auto text-center" style="width: 350px">
                                <h4 class="text-white">QUER COLABORAR E AJUDAR OUTROS GAMERS?</h4>
                                <button class="btn px-4 my-4 btn-principal text-white" type="button" style="border-radius:10px;">DOAR EQUIPAMENTO</button>
                            </div>

                            
                        </div>
                    </div>
            
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4 img-fundo-youtube">
                        <div class="w-100 p-5">
                            <h3 class="font-weight-bold text-white mt-4">YOUTUBE</h3>
                            <p class="text-principal font-weight-bold">Canal</p>
    
                            <button class="btn px-4 my-3" type="button" style="color:#fff;border-radius:10px;border:1 solid #fff;border-color:#fff;">Ver mais</button>
                        </div>
                    </div>
                    <div class="col-md-4 img-fundo-twitch">
                        <div class="w-100 p-5">
                            <h3 class="font-weight-bold text-white mt-4">TWITCH</h3>
                            <p class="text-principal font-weight-bold">Stream</p>
    
                            <button class="btn px-4 my-3" type="button" style="color:#fff;border-radius:10px;border:1 solid #fff;border-color:#fff;">Ver mais</button>
                        </div>
                    </div>
                    <div class="col-md-4 img-fundo-instagram">
                        <div class="w-100 p-5">
                            <h3 class="font-weight-bold text-white mt-4">INSTAGRAM</h3>
                            <p class="text-principal font-weight-bold">Rede social</p>
    
                            <button class="btn px-4 my-3" type="button" style="color:#fff;border-radius:10px;border:1 solid #fff;border-color:#fff;">Ver mais</button>
                        </div>
                    </div>
    
                </div>
            </div>
            <div class="container">
           
                <h4 class="text-center py-5"><b>ENTRE EM CONTATO</b></h4>
        
                <div class="row justify-content-center pb-5">
                    <div class="col-md-5 img-fundo-contato" style="border-radius:5px;">
                        <h5 class="text-white text-center w-75 mx-auto" style="margin-top:40%;margin-bottom:20%;"><b>Deixe sua mensagem que em breve nossa equipe retornará!</b></h5>
                    </div>
                    <div class="col-md-5" style="background-color:#1F0037; border-radius:5px; box-shadow: 5px 5px 2em black;">
                    
                        <p class="text-white text-center w-75 mx-auto my-3" ><b>Preencha o formulário</b></p>

                        <form class="text-center p-3">
                            <div class="form-group">
                              
                              <input type="text" class="icon-avatar form-person bg-segundaria" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Seu nome">
                              
                            </div>
                            <div class="form-group">
                              
                                <input type="text" class="icon-send form-person bg-segundaria" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email">
                                
                            </div>
                            <div class="form-group">
                              
                                <input type="text" class="icon-send form-person bg-segundaria" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Assunto">
                                
                            </div>
                            <div class="form-group">
                              
                                <textarea class="form-person bg-segundaria" id="exampleFormControlTextarea1" rows="3" placeholder="Escreva sua mensagem"></textarea>
                                
                            </div>

                            <button type="submit" class="btn btn-principal px-4 text-white">Enviar</button>
                        </form>


                        
                        
          
                    
                    </div>
                </div>
                
    
            </div>

            <?php if(count($patrocinadores) != 0): ?>
            <div class="container">
                <div class="w-100 mt-5">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-3">
                                 <div class="border w-100 my-3"></div>
                            </div>
                            <div class="col-12 col-md-5 text-center">
                             <h4><b>PARCEIROS</b></h4>
                            </div>
                            <div class="col-3">
                                 <div class="border w-100 my-3"></div>
                            </div>
                        </div>
                
                        <div class="row justify-content-center pb-4">
                            <?php $__currentLoopData = $patrocinadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patrocinio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-7 col-md-3 my-3">
                                    <div class="w-100 text-center">
                                        <div style="width: 100%;height:80px;">
                                            <img src="<?php echo e(env('APP_URL')); ?>/storage/img/patrocinadores/<?php echo e($patrocinio->imagem); ?>" style="width:100%;height:100%;object-fit: contain;">
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="container-fluid img-fundo-rodape">
                <div class="container">
                    <div class="row justify-content-center pt-5">
                        <div class="col-md-4 col-lg-3 mb-2">
                            <div class="w-100">
                                <p class="text-white font-weight-bold">REDE SOCIAL</p>

                                <div class="w-100 pt-3">
                                    <a href="#"><img src="<?php echo e(asset('assets/img/redes-sociais/icon-instagram.png')); ?>" alt="" class="mx-1" style="width: 30px"></a>
                                    <a href="#"><img src="<?php echo e(asset('assets/img/redes-sociais/icon-twitch.png')); ?>" alt="" class="mx-1" style="width: 30px"></a>
                                    <a href="#"><img src="<?php echo e(asset('assets/img/redes-sociais/icon-youtube.png')); ?>" alt="" class="mx-1" style="width: 38px"></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-lg-4 mb-2">
                            <div class="w-100 text-center">
                                
                                <p class="text-white font-weight-bold">MENU DO SITE</p>
                                <div class="row pt-3">
                                    <div class="col-6">
                                        <p><a href="" class="text-white" style="text-decoration:none">INICIO</a></p>
                                        <div class="border mx-auto w-75 my-3"></div>

                                        <p><a href="" class="text-white" style="text-decoration:none">SOBRE</a></p>
                                        <div class="border mx-auto w-75 my-3"></div>

                                        <p><a href="" class="text-white" style="text-decoration:none">RECRUTAMENTO</a></p>
                                        
                                    </div>
                                    <div class="col-6">
                                        <p><a href="" class="text-white" style="text-decoration:none">TORNEIO</a></p>
                                        <div class="border mx-auto w-75 my-3"></div>

                                        <p><a href="" class="text-white" style="text-decoration:none">EQUIPE</a></p>
                                        <div class="border mx-auto w-75 my-3"></div>

                                        <p><a href="" class="text-white" style="text-decoration:none">CONTRIBUA</a></p>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
            
                        <div class="col-md-4 col-lg-3 mb-2">
                            <div class="w-100">
                                <p class="text-white font-weight-bold">CONTATO</p>

                                <div class="w-100 pt-3">
                                    <p>
                                        <a href="#" class="text-white">
                                            <img src="<?php echo e(asset('assets/img/redes-sociais/icon-email.png')); ?>" alt="" class="mx-1" style="width: 20px">
                                            EMAIL@CONTATO.COM.BR
                                        </a>
                                    </p>
                                    <p>
                                        <a href="#" class="text-white">
                                            <img src="<?php echo e(asset('assets/img/redes-sociais/icon-whatsapp.png')); ?>" alt="" class="mx-1" style="width: 20px">
                                            48 9 1234 - 5678
                                        </a>
                                    </p>
                                    <p>
                                        <a href="#" class="text-white">
                                            <img src="<?php echo e(asset('assets/img/redes-sociais/icon-fone.png')); ?>" alt="" class="mx-1" style="width: 20px">
                                            48 3445 - 4564
                                        </a>
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="w-100 text-center">
                                <img src="<?php echo e(asset('assets/img/logo-principal.png')); ?>" alt="" class="mx-1" style="width: 80px">
                                <p class="text-secondary small"><b>NÃO SOMOS SÓ UM TIME SOMOS UMA FAMÍLIA</b></p>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </footer>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/js/libs/jquery.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/js/libs/bootstrap.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/js/navbar.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/js/inputFile.js')); ?>" defer></script>

</body>
</html>
<?php /**PATH C:\Xampp_server\htdocs\dev-upwins\undergroundcla.com.br\resources\views/layouts/app.blade.php ENDPATH**/ ?>