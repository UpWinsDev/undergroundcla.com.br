

<?php $__env->startSection('content'); ?>

<div class="w-100 img-fundo-sobre">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10" style="margin-top: 10%;height:650px;">
                <img src="./img/icones/not1.png" alt="" style="width: 70%;margin-bottom: 10%;">
                <h1 class="text-white" style="font-size:60px;"><b>NOSSA <br><span style="color:#FF8F1C;">HISTÓRIA</span> </b></h1>
                <p class="text-white py-3" style="width: 350px">A ST foi fundada em 2018 por <b>RAFAEL MARTINS</b> conhecido como <b>VACCAXX</b>, na franquia SCUM. Inicialmente era apenas um hobby, ele tinha 13 anos e naquela época o esporte digital no Brasil nem existia. Foi em 2007 o primeiro campeonato mundial de SCUM.
                </p>

                <button class="btn px-4 btn-principal text-white" type="button" style="border-radius:10px;">FAÇA PARTE DO TIME</button>
            </div>
        </div>

    </div>
</div>

<div class="w-100" style="background: #181818;">
    <div class="container">
        <div class="row justify-content-center pt-5">
            <div class="col-3">
                <div class="border w-100 my-3"></div>
            </div>
            <div class="col-12 col-md-3 text-center">
                <h4 class="text-white">ADMINISTRADORES</h4>
            </div>
            <div class="col-3 pb-4">
                <div class="border w-100 my-3"></div>
            </div>
        </div>

        <div class="row justify-content-center pb-5">

            <?php
                $i = 1
            ?>

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if(!empty($user->user_players[0])): ?>

                    <div class="col-12 col-md-3 my-3">
                        <div style="border-radius: 10px 10px;background-color:#fff;">
                            <div class="text-center" style="border-radius: 10px 10px;width: 100%;height:190px;">
                                <img src="<?php echo e(env('APP_URL')); ?>/assets/img/avatars/persona-<?php echo e($i); ?>.png" class="mt-1" style="width:60%;height:100%;object-fit: cover;">
                            </div>
                            <div class="text-center text-white" style="border-radius: 10px 10px;width: 100%;height:110px; border:3px solid #444444; background-color:#444444;">
                                <h5 class="card-title mt-3"><?php echo e($user->user_players[0]->nome); ?></h5>
                                <span><?php echo e($user->user_players[0]->descricao); ?></span>
                            </div>
                        </div>
                    </div>

                    <?php if($i == 4): ?>
                        <?php echo e($i = 1); ?>

                    <?php endif; ?>
                    
                <?php endif; ?>

                
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

            <div class="col-md-12">
                <p class="text-white text-center w-75 mx-auto">
                    Nossa missão é oferecer o melhor possível aos nossos jogadores enquanto trazemos alegria à nossa torcida. Ano após ano estamos evoluindo para sermos a maior família gamer do mundo
                </p>
            </div>
        
        </div>

        
    </div>



    
   
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp_server\htdocs\dev-upwins\undergroundcla.com.br\resources\views/website/sobre/index.blade.php ENDPATH**/ ?>