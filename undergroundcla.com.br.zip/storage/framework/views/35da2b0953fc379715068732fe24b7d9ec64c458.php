

<?php $__env->startSection('content'); ?>


<div class="row justify-content-center" style="height: 600px">


    <div class="col-md-10">

      <div class="w-100 text-center mt-5">
        <h3 class="text-white"><b>TIME - <?php echo e($time->nome); ?></b></h3>
    </div>

    <div class="col-md-12">
      <?php if(Session::has('mensagem-falha')): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong>Ops!</strong> <?php echo e(Session::get('mensagem-falha')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>
          
      <?php endif; ?>
      <?php if(Session::has('mensagem-sucesso')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong>Show!</strong> <?php echo e(Session::get('mensagem-sucesso')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>
          
      <?php endif; ?>
  </div>


      
    <div class="w-100 my-3">
      <a class="btn btn-primary" role="button" href="<?php echo e(route('times.index')); ?>">Voltar</a>
        
    </div>

    <div class="w-100 bg-white p-3 mb-5" style="border-radius:10px;">
      <table class="data-table-style table table-responsive-md">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Id Steam</th>
            <th scope="col">Nome</th>
            <th scope="col">Descricao</th>
            <th scope="col">Função</th>
            <th scope="col">Opções</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($player->times_player->id); ?></th>
                    <td><?php echo e($player->times_player->player_users->steamid); ?></td>
                    <td><?php echo e($player->times_player->nome); ?></td>
                    <td><?php echo e($player->times_player->descricao); ?></td>
                    <td><?php echo e($player->funcao); ?></td>
                    <td class="text-center"style="width: 180px">
                       
                        <a class="btn btn-info" role="button" href="<?php echo e(route('playerTimes.edit', ['id'=> $player->id])); ?>" data-toggle="tooltip" data-placement="top" title="Editar">
                          <img src="<?php echo e(asset('assets/img/edit.png')); ?>" class="mb-1" alt="" style="width:20px;">
                        </a>  
                        <a class="btn btn-danger" role="button" href="<?php echo e(route('playerTimes.destroy', ['id'=> $player->id])); ?>" data-toggle="tooltip" data-placement="top" title="Excluir">
                          <img src="<?php echo e(asset('assets/img/excluir.png')); ?>" alt="" style="width:25px;">
                        </a>  
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    </div>
    

    


  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp_server\htdocs\dev-upwins\undergroundcla.com.br\resources\views/admin/playerTimes/index.blade.php ENDPATH**/ ?>