

<?php $__env->startSection('content'); ?>


<div class="row justify-content-center" style="height: 600px">


    <div class="col-md-10">

      <div class="w-100 text-center mt-5">
        <h3 class="text-white"><b>TIMES DO PLAYER</b></h3>
    </div>

    <div class="col-md-12">
      <?php if(Session::has('mensagem-falha')): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong>Ops!</strong> <?php echo e(Session::get('mensagem-falha')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>
          
      <?php endif; ?>
      <?php if(Session::has('mensagem-sucesso')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong>Show!</strong> <?php echo e(Session::get('mensagem-sucesso')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>
          
      <?php endif; ?>
  </div>


      
    <div class="w-100 my-3">
        <a class="btn btn-primary" role="button" href="<?php echo e(route('players.index')); ?>">Voltar</a>
        <a class="btn btn-info" role="button" href="<?php echo e(route('playerTimes.create',['id'=> $id ])); ?>"><img src="<?php echo e(asset('assets/img/add.png')); ?>" class="mb-1" alt="" style="width:20px;"> Add a time</a>
    </div>

    <div class="w-100 bg-white p-3 mb-5" style="border-radius:10px;">
      <table class="data-table-style table table-responsive-md">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Nome</th>
            <th scope="col">Função</th>
            <th scope="col">Time</th>
            <th scope="col">Game</th>

          </tr>
        </thead>
        <tbody>
            <?php if(count($players) >= 0): ?>
            <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($player->times_player->id); ?></th>
                    <td><?php echo e($player->times_player->nome); ?></td>
                    <td><?php echo e($player->funcao); ?></td>
                    <td><?php echo e($player->times_time->nome); ?></td>
                    <td><?php echo e($player->times_time->time_game->nome); ?></td>
                    


                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
      </table>
    </div>
    </div>
    

    


  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp_server\htdocs\dev-upwins\undergroundcla.com.br\resources\views/admin/players/times.blade.php ENDPATH**/ ?>