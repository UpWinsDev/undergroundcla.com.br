

<?php $__env->startSection('content'); ?>


<div class="row justify-content-center" style="height: 600px">


    <div class="col-md-10">

      <div class="w-100 text-center mt-5">
        <h3 class="text-white"><b>CONTRIBUIÇÕES</b></h3>
    </div>

    <div class="col-md-12">
      <?php if(Session::has('mensagem-falha')): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong>Ops!</strong> <?php echo e(Session::get('mensagem-falha')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>
          
      <?php endif; ?>
      <?php if(Session::has('mensagem-sucesso')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong>Show!</strong> <?php echo e(Session::get('mensagem-sucesso')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>
          
      <?php endif; ?>
  </div>


    

    <div class="w-100 bg-white p-3 mb-5" style="border-radius:10px;">
      <table class="data-table-style table table-responsive-md">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Titulo</th>
            <th scope="col">Descrição</th>
            <th scope="col">status</th>
            <th scope="col">Img</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $contribuicoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contribuicao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($contribuicao->id); ?></th>
                    <td><?php echo e($contribuicao->titulo); ?></td>
                    <td><?php echo e($contribuicao->descricao); ?></td>
                    <td><?php echo e($contribuicao->status); ?></td>
                    <td>
                      <div  style="border-radius: 10px 10px 0px 0px;width: 100%;height:160px;">
                        <img src="<?php echo e(env('APP_URL')); ?>/storage/img/contribuicao/<?php echo e($contribuicao->id_user); ?>/<?php echo e($contribuicao->imagem); ?>" class="mt-2" style="width:100px;height:100px;object-fit: cover;">
                      </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    </div>
    

    


  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp_server\htdocs\dev-upwins\undergroundcla.com.br\resources\views/admin/contribuicoes/index.blade.php ENDPATH**/ ?>