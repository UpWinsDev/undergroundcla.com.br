

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center mb-5">


    <div class="col-md-6">

      

    <div class="w-100 text-center my-5">
        <h3 class="text-white"><b>CADASTRAR TIMES SQUAD</b></h3>
    </div>

    <div class="col-md-12">
        <?php if(Session::has('mensagem-falha')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Ops!</strong> <?php echo e(Session::get('mensagem-falha')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
        <?php endif; ?>
        <?php if(Session::has('mensagem-sucesso')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Show!</strong> <?php echo e(Session::get('mensagem-sucesso')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
        <?php endif; ?>
    </div>

        <div class="w-100 bg-white p-3 mb-5" style="border-radius:10px;">
          <form action="<?php echo e(route('times.create.do')); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <div class="form-row">
              <div class="form-group col-md-12">
                <label for="titulo">Titulo</label>
                <input type="text" class="form-control" id="titulo" name="titulo" required>
              </div>
              <div class="form-group col-md-12">
                <label for="descricao">Descrição</label>
                <textarea class="form-control" d="descricao" name="descricao" rows="3"></textarea>
              </div>
              <div class="form-group col-md-12">
                <label for="id_game">Game</label>
                <select class="form-control" id="id_game" name="id_game">
                    <option>Selecione game</option>
                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($game->id); ?>"><?php echo e($game->nome); ?></option>
                    
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
  
            </div>
            <a class="btn btn-primary" role="button" href="<?php echo e(route('times.index')); ?>">Voltar</a>
            <button class="btn btn-success" type="submit">Salvar</button>
          </form>
        </div>

    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp_server\htdocs\dev-upwins\undergroundcla.com.br\resources\views/admin/times/create.blade.php ENDPATH**/ ?>