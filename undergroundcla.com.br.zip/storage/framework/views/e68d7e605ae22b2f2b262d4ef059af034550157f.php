

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center text-center">

        <div class="col">
            <h3>escudos</h3>
        </div>
            
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp_server\htdocs\dev-upwins\undergroundcla.com.br\resources\views/admin/escudos/index.blade.php ENDPATH**/ ?>