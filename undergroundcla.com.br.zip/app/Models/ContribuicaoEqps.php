<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContribuicaoEqps extends Model
{
    use HasFactory;

    protected $table = 'contribuicao_eqps';

    /**
     * The attributes that are mass assignable.
     *
     *@var array
     */
    protected $fillable = [
        'id_user', 
        'titulo', 
        'descricao',
        'imagem',
        'status'
    ];
}
